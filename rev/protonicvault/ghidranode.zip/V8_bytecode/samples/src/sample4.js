function sample4(n) {
	alert();
	n = prompt("Hell" + "o!");
	alert( !NaN );
	console.log( n--, !n); 
	console.log(typeof n, String(n), "");
	return prompt("123" | 4, n++)
}

