function func(n) {
	if (n > 1) {
		alert(n*n+12);
		return 1;
	} else{
		return -1;
	}
}
