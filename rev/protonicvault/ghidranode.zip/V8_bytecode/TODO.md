#TODO:

1) function arguments order
2) types
3) imports
4) semantics for pcodeop stub instructions