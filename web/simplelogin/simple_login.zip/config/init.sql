CREATE DATABASE challenge;
USE challenge;

CREATE TABLE users (
    user varchar(256),
    password varchar(256)
);

INSERT INTO users VALUES ("admin", "you_realy_think_that_would_be_that_much_simple :))))");
